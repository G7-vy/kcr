package com.example.music118;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{   private Button bStart;
    private Button bStop;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {   super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bStart = (Button) findViewById(R.id.btnStart);
        bStop = (Button) findViewById(R.id.btnStop);

        bStart.setOnClickListener(this);
        bStop.setOnClickListener(this);
    }
    @Override
    public void onClick(View v){
        if(v==bStart){
            startService(new Intent(this,MediaService.class));
        }
        else(v==bStop){
            stopService(new Intent(this,MediaService.class));
        }
    }

}


